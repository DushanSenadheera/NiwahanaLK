-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 10, 2022 at 07:00 PM
-- Server version: 10.4.21-MariaDB
-- PHP Version: 8.0.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `niwahana`
--

-- --------------------------------------------------------

--
-- Table structure for table `addimage`
--

CREATE TABLE `addimage` (
  `id` int(20) NOT NULL,
  `mainId` varchar(20) NOT NULL,
  `image` varchar(300) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `addimage`
--

INSERT INTO `addimage` (`id`, `mainId`, `image`) VALUES
(1, '1', 'house-3.png'),
(2, '1', 'house-4.png'),
(3, '1', 'house-5.png'),
(4, '2', 'WhatsApp Image 2022-03-20 at 6.40.23 PM.jpeg'),
(5, '2', 'WhatsApp Image 2022-03-20 at 6.35.16 PM.jpeg'),
(6, '2', 'WhatsApp Image 2022-03-20 at 6.35.15 PM (1).jpeg'),
(7, '3', 'WhatsApp Image 2022-03-20 at 6.40.28 PM.jpeg'),
(8, '3', 'WhatsApp Image 2022-03-20 at 6.40.25 PM (1).jpeg'),
(9, '3', 'WhatsApp Image 2022-03-20 at 6.35.15 PM.jpeg'),
(10, '3', 'WhatsApp Image 2022-03-20 at 6.30.40 PM (1).jpeg'),
(11, '4', 'WhatsApp Image 2022-03-20 at 6.40.28 PM.jpeg'),
(12, '4', 'WhatsApp Image 2022-03-20 at 6.35.15 PM.jpeg'),
(13, '4', 'WhatsApp Image 2022-03-20 at 6.30.40 PM (1).jpeg'),
(14, '5', 'Contemporary-Modern-House-Design-6.1539270983.8601.jpg'),
(15, '5', 'feature-LivingRoom-091_TREES_HH_AP20_40.jpg'),
(16, '5', 'room-bed-nightstands-table.jpg'),
(17, '6', 'Contemporary-Modern-House-Design-6.1539270983.8601.jpg'),
(18, '6', 'feature-LivingRoom-091_TREES_HH_AP20_40.jpg'),
(19, '6', 'room-bed-nightstands-table.jpg'),
(20, '7', 'Contemporary-Modern-House-Design-6.1539270983.8601.jpg'),
(21, '7', 'feature-LivingRoom-091_TREES_HH_AP20_40.jpg'),
(22, '7', 'room-bed-nightstands-table.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `userName` varchar(30) NOT NULL,
  `password` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `userName`, `password`) VALUES
(1, 'admin@mail.com', '1234');

-- --------------------------------------------------------

--
-- Table structure for table `advertisement`
--

CREATE TABLE `advertisement` (
  `ad id` int(11) NOT NULL,
  `title` text NOT NULL,
  `image` varchar(30) NOT NULL,
  `price` int(15) NOT NULL,
  `location` text NOT NULL,
  `mobile` int(10) NOT NULL,
  `bathroom` int(10) NOT NULL,
  `bedroom` int(10) NOT NULL,
  `area` int(200) NOT NULL,
  `story` int(5) NOT NULL,
  `description` text NOT NULL,
  `user` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `advertisement`
--

INSERT INTO `advertisement` (`ad id`, `title`, `image`, `price`, `location`, `mobile`, `bathroom`, `bedroom`, `area`, `story`, `description`, `user`) VALUES
(1, 'Modern house for sale in Colombo', '', 85000000, 'Colombo', 754215962, 3, 3, 16, 2, 'Luxury modern house for sale in Colombo\r\n\r\nPrime location\r\nAddress: Riverside Garden, Colombo\r\nLand Extent: 16 perches\r\n2 story house\r\n3 bedrooms\r\n3 bathrooms\r\nCan park 2 vehicles\r\nPrice - 85M can be negotiable', '1'),
(2, 'House for sale in Rajagiriya', '', 75000000, 'Rajagiriya', 763848510, 5, 2, 15, 2, 'Prime location\r\nAddress: Kariyawasam place , Buthgamuwa road , Rajagiriya\r\n3 KM to Rajagiriya Town\r\n1 KM to IDH Junction\r\nfacility for 2 vehicles, servant quarters with room/ toilets\r\nSemi-Furnished.\r\nUpper indoor garden\r\nThe landscaped garden surrounding the house\r\n', '3'),
(4, 'House for sale in kandy', '', 38000000, 'Kandy', 762390238, 2, 3, 20, 2, 'This Remarkable Place is located in a higher elevator, with a lot of greenery surrounded by the property.\r\n\r\nlocation -38/2 Yagghapitiya amungama kandy\r\n5 Km distance from Kandy\r\n\r\nOne Basement Parking for 2 vehicles.\r\n\r\nWater supply from the mainline and also from a well\r\n\r\nLarge landscaped garden.', '2');

-- --------------------------------------------------------

--
-- Table structure for table `banner`
--

CREATE TABLE `banner` (
  `id` int(11) NOT NULL,
  `name` varchar(30) NOT NULL,
  `description` varchar(60) NOT NULL,
  `bannerImg` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `registration`
--

CREATE TABLE `registration` (
  `user id` int(11) NOT NULL,
  `fName` text NOT NULL,
  `lname` text NOT NULL,
  `email` varchar(40) NOT NULL,
  `mobile` int(10) NOT NULL,
  `password` varchar(12) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `registration`
--

INSERT INTO `registration` (`user id`, `fName`, `lname`, `email`, `mobile`, `password`) VALUES
(1, 'Dushan', 'Senadheera', 'dushan@gmail.com', 762311976, '12345678'),
(2, 'Tharuni', 'Diwyanjalee', 'tharuni@gmail.com', 762390238, '12345678'),
(3, 'Amith', 'Gamagedara', 'amith@gmail.com', 763848510, '12345678'),
(4, 'haruni', 'bandara', 'haruni@gmail.com', 711231234, 'asdfg'),
(5, 'saradha', 'senawirathna', 'saradha@gmail.com', 123123123, 'qweasd'),
(6, 'sathsarani', 'perera', 'sathsarani@gmail.com', 2147483647, 'qwerasdf'),
(7, 'binuri', 'bandara', 'binuri@gmail.com', 701323123, '12341234');

-- --------------------------------------------------------

--
-- Table structure for table `report`
--

CREATE TABLE `report` (
  `id` int(200) NOT NULL,
  `description` varchar(200) NOT NULL,
  `itemId` varchar(200) NOT NULL,
  `user` varchar(200) NOT NULL,
  `date` varchar(200) NOT NULL,
  `time` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `report`
--

INSERT INTO `report` (`id`, `description`, `itemId`, `user`, `date`, `time`) VALUES
(1, 'this ad contains fake details from someone else', '1', '2', '2022-04-10', '15:32:28'),
(2, 'property details are fake', '2', '3', '2022-04-10', '17:30:05'),
(3, 'details are fake', '1', '3', '2022-04-10', '18:01:08');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `addimage`
--
ALTER TABLE `addimage`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `advertisement`
--
ALTER TABLE `advertisement`
  ADD PRIMARY KEY (`ad id`);

--
-- Indexes for table `banner`
--
ALTER TABLE `banner`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `registration`
--
ALTER TABLE `registration`
  ADD PRIMARY KEY (`user id`);

--
-- Indexes for table `report`
--
ALTER TABLE `report`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `addimage`
--
ALTER TABLE `addimage`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `advertisement`
--
ALTER TABLE `advertisement`
  MODIFY `ad id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `banner`
--
ALTER TABLE `banner`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `registration`
--
ALTER TABLE `registration`
  MODIFY `user id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `report`
--
ALTER TABLE `report`
  MODIFY `id` int(200) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
